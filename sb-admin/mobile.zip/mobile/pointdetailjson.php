<?php
$host="mysql13.000webhost.com"; // Host name
$username="a1056688_tanning"; // Mysql username
$password="lavi2088"; // Mysql password
$db_name="a1056688_tanning"; // Database name
$tbl_name="sharepagedetail"; // Table name

// Connect to server and select databse.
mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");


if(isset($_GET['userid']) ) {
//echo "enter";
  /* soak in the passed variable or set our own */
  $number_of_posts = isset($_GET['num']) ; //10 is the default
  $format = strtolower($_GET['format']) == 'json' ? 'json' : 'xml'; //xml is the default
  $user_id = intval($_GET['user']); //no default
  
  ///new data
  
  $tbl_name="YouTubeDetail"; // Table name






$sql="SELECT * FROM userdetail where userid='".$_GET['userid']."'";
$result=mysql_query($sql);
  
  //end of new data

  /* connect to the db */
 
  /* create one master array of the records */
  $posts = array();
  if(mysql_num_rows($result)) {
    while($post = mysql_fetch_assoc($result)) {
      $posts[] = array('post'=>$post);
    }
  }

  /* output in necessary format */
  if($format == 'json') {
    header('Content-type: application/json');
    echo json_encode(array('posts'=>$posts));
  }
  else {
    header('Content-type: text/xml');
    echo '<posts>';
    foreach($posts as $index => $post) {
      if(is_array($post)) {
        foreach($post as $key => $value) {
          echo '<',$key,'>';
          if(is_array($value)) {
            foreach($value as $tag => $val) {
              echo '<',$tag,'>',htmlentities($val),'</',$tag,'>';
            }
          }
          echo '</',$key,'>';
        }
      }
    }
    echo '</posts>';
  }

  /* disconnect from the db */
  @mysql_close($link);
}
else{
//echo 'close';
}
?>