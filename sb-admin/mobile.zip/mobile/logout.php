<?
session_start();
session_destroy();
?>

<html>
<body>
<h1>Logout</h1>
</body>

</html>