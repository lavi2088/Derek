<?php
$host="mysql13.000webhost.com"; // Host name
$username="a1056688_tanning"; // Mysql username
$password="lavi2088"; // Mysql password
$db_name="a1056688_tanning"; // Database name
$tbl_name="sharepagedetail"; // Table name

// Connect to server and select databse.
$conn=mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");
echo "get userid".$_POST['userid'];
$userid=$_POST['userid'];
$type=$_POST['type'];
$postid=$_POST['postid'];

$sqlUpdateShare="update sharepagedetail set status='Y' where postid='".$postid."'";



echo $sqlUpdate;
$result=mysql_query($sqlUpdateShare);

if($result){
echo "success";

}
else{
echo "".mysql_error();
}





mysql_close($conn);

?>	