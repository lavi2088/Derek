<?php
// Create connection

$mysql_host = "mysql8.000webhost.com";
$mysql_database = "a1136591_tanning";
$mysql_user = "a1136591_tanning";
$mysql_password = "lavi2088";

$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_database);

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
else{
echo " connected to MySQL: ";
}
?>